## DRAMA
- #### This is a wrapper for the pylcp package
- #### parallelized with `multiprocessing`, designed to run on HPC  
